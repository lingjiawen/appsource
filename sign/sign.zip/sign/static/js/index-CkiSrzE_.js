import{d as e,e as n,o}from"./index-BaSFIESJ.js";const s=e({name:"About",__name:"index",setup(t){return(a,r)=>(o(),n("div",null,"about"))}});export{s as default};
